# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# The bigMap Package for R.

# Copyright (c) 2018, Joan Garriga <jgarriga@ceab.csic.es>, Frederic Bartumeus <fbartu@ceab.csic.es> (Blanes Centre for Advanced Studies, CEAB-CSIC).

# bigMap is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

# bigMap is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#' Example dataset
#'
#' Loads an example of a mapping of a dataset.
#'
#' @return An example \var{bdm} instance named \var{exMap}.
#'
#' @details A \var{bdm} instance is a list with elements: \var{$dSet} a name identifying the dataset (\code{bdm.fName()} use this name to generate a default file name); \var{$data} a matrix with raw data; \var{$lbls} a vector of datapoint labels (in case they are known); \var{$N} the dataset size; \var{$is.distance} a logical value that is set to TRUE when the raw data is a distance matrix. Downstream steps of the mapping protocol will add more elements to the list.
#'
#' This example is based on a small synthetic dataset with \code{n = 5000} observations drawn from a 4-variate Gaussian Mixture Model (GMM) with 16 Gaussian components.
#'
#' @examples
#'
#' # --- load example dataset
#' bdm.example()
#' str(exMap)

bdm.example <- function()
{
	load(paste(paste(system.file('extdata', package = 'bigMap'), '/', sep = ''), 'exData.RData', sep=''), envir=parent.frame(), verbose=T)
	load(paste(paste(system.file('extdata', package = 'bigMap'), '/', sep = ''), 'exMap.RData', sep=''), envir=parent.frame(), verbose=T)
}


#' Create \var{bdm} instance
#'
#' Computes the precision parameters beta_i for the given perplexity (local bandwidths for the input affinity kernels) and returns them in a \var{bdm} instance. A \var{bdm} instance is a list with the supplied info (type of inpu data and perplexity) and the precision parameters that have been computed. This list is the starting object to which new elements are added at each step of the mapping protocol.
#'
#' @param dSet.name The name given to the input dataset (optional). This name will be used to automatically generate a name to save the output as an \var{.Rdata} file.
#'
#' @param dSet.data A \var{data.frame} or \var{matrix} with raw input-data. The dataset must not have duplicated rows.
#'
#' @param is.distance A logical value (FALSE by default). TRUE indicates that raw data is a distance matrix.
#'
#' @param is.sparse A logical value (FALSE by default). TRUE indicates that the raw data is a sparse matrix.
#'
#' @param perplexity The value of perplexity to compute similarities (default value is 100).
#'
#' @param threads The number of parallel threads (in principle only limited by hardware resources, \code{i.e.} number of cores and available memory)
#'
#' @param type The type of cluster: 'SOCK' (default) for intra-node parallelization, 'MPI' (\code{message passing interface}) for inter-node parallelization.
#'
#' @param labels If available, labels can be included as a separate vector of length equal to \code{nrow(dSet.data)}. Label values are factorized as \code{as.numeric(as.factor(labels))}.
#'
#' @return A \var{bdm} instance. A \var{bdm} instance is a list with the supplied info and the precision parameters computed for the given perplexity. This list is the starting object to which new elements are added at each step of the mapping protocol.
#'
#' @examples
#'
#' # --- load example dataset
#' bdm.example()
#' # --- perform ptSNE
#' \dontrun{
#' myMap <- bdm.init(exData[, 1:4], dSet.name = 'ex', perplexity = 250, threads = 4, labels = exData[, 5])
#' }

bdm.init <- function(dSet.data, dSet.name = NULL, is.distance = F, is.sparse = F, normalize = T, perplexity = 100, dSet.labels = NULL, threads = 4, mpi.cl = NULL)
{
	bdm <- list()
	if (is.null(dSet.name)) dSet.name = '__'
	bdm$dSet <- dSet.name
	# check dSet.data is given as fileName.csv
	if (class(dSet.data) == 'character') {
	 	if (!file.exists(dSet.data)) {
			message('+++ Data file not found !! \n')
			return(FALSE)
		}
		bdm$dataFile <- dSet.data
	}
	bdm$is.distance <- is.distance
	bdm$is.sparse <- is.sparse
	bdm$normalize <- normalize
	# compute betas
	if (threads > 0) {
		# start cluster
		cl <- cluster.start(threads, mpi.cl)
		# export data
		Xdata.exp(cl, dSet.data, is.distance, is.sparse, normalize = normalize)
		dimX <- Xdata.dim(cl)
		bdm$nX <- dimX[1]
		bdm$mX <- dimX[2]
		# compute betas
		if (length(perplexity) == 1) {
			bdm$ppx <- list(beta.get(cl, perplexity))
		} else {
			bdm$ppx <- lapply(perplexity, function(ppx) beta.get(cl, ppx))
		}
		# stop cluster
		if (is.null(mpi.cl)) cluster.stop(cl)
	}
	# attach labels
	if (!is.null(dSet.labels)) bdm$lbls <- as.numeric(as.factor(dSet.labels))
	return(bdm)
}

#' Default \var{bdm} file name
#'
#' Generates a default file name. The default file name is intended for functions \code{bdm.save()} and \code{bdm.scp()} to ease the task of working/organizing multiple runs on the same dataset.
#'
#' @param bdm A \var{bdm} instance as generated by \code{bdm.init()}.
#'
#' @details The file name is generated based on \code{bdm$dSet} and main ptSNE parameters (threads, layers, rounds, boost and perplexity). In case that \code{bdm.wtt()} has been performed on any of the layers, the number of clusters in the first not null layer of bdm$wtt is also included.
#'
#' @return A \var{*.RData} file name based on \var{bdm$dSet} and main \var{bdm} parameters.
#'
#' @examples
#'
#' bdm.example()
#' str(exMap$dSet)
#' str(exMap$ptsne)
#' bdm.fName(exMap)

bdm.fName <- function(bdm)
{
	fName <- paste(bdm.mybdm(), bdm$dSet, sep = '')
	if (!is.null(bdm$ptsne))
	{
		p <- paste('_ppx', bdm$ppx$ppx, sep = '')
		fName <- paste(fName, p, sep = '')
		if (!is.null(bdm$wtt))
		{
			if (!is.null(bdm$merge)) {
				s <- length(unique(bdm$merge$C))
				k <- paste('_m', formatC(s, width = 2, flag = '0'), sep = '')
			} else {
				s <- lapply(bdm$wtt, function(wtt) wtt$s)
				k <- paste('_k', formatC(s[[1]], width = 2, flag = '0'), sep = '')
			}
			fName <- paste(fName, k, sep = '')
		}
	}
	return(paste(fName, '.RData', sep = ''))
}


#' Save \var{bdm} instance
#'
#' Saves a \var{bdm} instance with default path/file names, as given by \code{bdm.mybdm()/bdm.fName(bdm)}. Default file name is generated based on \code{bdm$dSet} and ptSNE main parameters (threads, layers, boost, rounds, perplexity).  The purpose of functions \code{bdm.save()} and \code{bdm.scp()} used with \code{bdm.fName()} is to ease the task of working/organizing multiple runs on the same dataset.
#'
#' @param ... A \var{bdm} instance as generated by \code{bdm.init()}.
#'
#' @return None
#'
#' @examples
#'
#' # --- get a matrix with raw-data
#' mydata <- cbind(rnorm(10000, mean = 0, sd = 3),  ncol = 2)
#' mylabels <- apply(mydata, 1, function(row) round(sqrt(sum(row**2)), 0))
#' # --- create a \var{bdm} instance with our raw-data matrix
#' mybdm <- bdm.init('mydataset', mydata, labels = mylabels)
#' str(mybdm)
#' # --- save it
#' \dontrun{
#' bdm.save(mybdm)
#' }

bdm.save <- function( ... ){
	bdm <- get(deparse(substitute( ... )), envir = parent.frame())
	fName <- bdm.fName(bdm)
	if (!file.exists(bdm.mybdm())) {
		cat('+++ Error: default path', bdm.mybdm(), 'does not exist. \n')
	}
	else {
		bdm$raw.data <- NULL
		save(..., envir = parent.frame(), file = fName)
		cat('+++ saved to ', fName, '\n', sep='')
	}
}


#' Transfer \var{bdm} instance to a remote machine.
#'
#' Transfers a \var{bdm} instance to a remote machine. By default a file name is generated based on \code{bdm$dSet} and t-SNE main parameters (threads, layers, rounds, perplexity). The purpose of functions \code{bdm.save()} and \code{bdm.scp()} used with \code{bdm.fName()} is to ease the task of working/organizing multiple runs on the same dataset.
#'
#' @param ... A \var{bdm} instance as generated by \code{bdm.init()}.
#'
#' @param dest The name or IP address of a remote machine where to transfer the file of the \var{bdm} instance. By default is send to \var{bdm.local()} environment variable.
#'
#' @return None
#'
#' @examples
#'
#' \dontrun{
#' # --- load example
#' bdm.example()
#' # --- scp to \var{bdm.local()} with default file name
#' bdm.scp(exMap)
#' # --- scp to IP address 'xxx.xxx.0.0' with default file name
#' bdm.scp(exMap, dest = 'xxx.xxx.0.0')
#' }

bdm.scp <- function( ... , dest = NULL){
	bdm <- get(deparse(substitute( ... )), envir = parent.frame())
	bdm.save( ... )
	if (is.null(dest)){
		dest <- bdm.local()
	}
	if (substr(dest, 1, 7) == 'xxx.xxx'){
		cat('+++ WARNING: bdm.local() not set !! \n')
	}
	else {
		fName <- bdm.fName(bdm)
		dest.fName <- paste(dest, fName, sep = ':')
		system(paste('scp', fName, dest.fName))
	}
}

#' Parallelized t-SNE
#'
#' Starts the ptSNE algorithm (first step of the mapping protocol).
#'
#' @param data Input data (a matrix, a big.matrix or a .csv file name).
#'
#' @param bdm A \var{bdm} instance as generated by \code{bdm.init()}.
#'
#' @param lRate Learning-rate. (By default \code{lRate=NULL} it is adjusted to \code{n *layers /threads /16}.
#'
#' @param theta Accuracy/speed trade-off factor, a value between 0.33 and 0.8. (Default value is \code{theta = 0.0}). If \code{theta < 0.33} the algorithm uses the exact computation of the gradient. The closer is this value to 1 the faster is the computation but the coarser is the approximation of the gradient.
#'
#' @param alpha Momentum factor (Default value is \code{alpha=0.5}).
#'
#' @param Y.init A \code{n *2 *layers} matrix with initial mapping positions. (By default \code{Y.init=NULL} will use random initial positions).
#'
#' @param info Output information: 1 yields inter-round results, 0 disables intermediate results. Default value is 0.
#'
#' @param threads Number of parallel threads (according to data size and hardware resources, \code{i.e.} number of cores and available memory. Default value is \code{threads = 4}).
#'
#' @param mpi.cl MPI (inter-node parallelization) cluster as generated by \code{bdm.mpi.start()}. (By default \code{mpi.cl = NULL} a 'SOCK' (intra-node parallelization) cluster is generated).
#'
#' @param layers Number of layers (\code{minimum} 2, \code{maximum} the number of threads).
#'
#' @param rounds Number of rounds (1 by default).
#'
#' @return A copy of the input \var{bdm} instance with new element \var{bdm$ptsne} (t-SNE output).
#'
#' @examples
#'
#' # --- load example dataset
#' bdm.example()
#' # --- perform ptSNE
#' \dontrun{
#' exMap <- bdm.ptsne(exMap, threads = 10, layers = 2, rounds = 2, ppx = 200)
#' }
#' # --- plot the Cost function
#' bdm.cost(exMap)
#' # --- plot ptSNE output
#' bdm.ptsne.plot(exMap)

bdm.ptsne <- function(data, bdm, lRate = NULL, theta = 0.0, alpha = 0.5, Y.init = NULL, info = 0, threads = 3, mpi.cl = NULL, layers = 2, rounds = 1)
{
	# +++ sanity check
	if (!is.null(Y.init) && (ncol(Y.init) != 2 *layers)) {
		return(message('+++ ncol(Y.init) does not match the number of layers !! \n'))
	}
	if (layers > threads) {
		cat('+++ WARNING: layers set to ', threads, ' !!\n', sep='')
		layers <- threads
	}
	if (is.null(lRate)) {
		lRate <- (bdm$nX *layers /threads) /16
	}
	if (theta > 0.0 && theta < 0.33) {
		cat('+++ WARNING: theta set to ', 0.0, ' !!\n', sep='')
		theta <- 0.0
	} else if (theta > 0.8) {
		cat('+++ WARNING: theta set to ', 0.8, ' !!\n', sep='')
		theta <- 0.8
	}
	# +++ start cluster of workers
	bdm$t <- list()
	cl <- cluster.start(threads, mpi.cl)
	if (is.null(cl)) return(bdm)
	# export data (if using mpi.cl it might have been already exported)
	if (is.null(mpi.cl) || !is.null(data)) {
		cat('+++ exporting data \n')
		bdm$t$dataExport <- system.time({
			Xdata.exp(cl, data, bdm$is.distance, bdm$is.sparse, normalize = bdm$normalize)
		})
		print(bdm$t$dataExport)
	}
	#
	bdm$ptsne <- list(threads = threads, layers = layers, rounds = rounds, lRate = lRate, theta = theta, alpha = alpha, Y = Y.init, useEx = 1.0)
	#
	bdm <- ptsne.get(cl, bdm, info)
	if (length(bdm) == 1) bdm <- bdm[[1]]
	# stop cluster
	stopCluster(cl)
	return(bdm)
}

bdm.restart <- function(data, bdm, epochs = NULL, iters = NULL, info = 0, threads = NULL, mpi.cl = NULL, layers = NULL) {
	# +++ start cluster of workers
	if (!is.null(threads)) bdm$ptsne$threads <- threads
	if (!is.null(layers)) bdm$ptsne$layers <- layers
	cl <- cluster.start(bdm$ptsne$threads, mpi.cl)
	if (is.null(cl)) return(bdm)
	# export data (if using mpi.cl it might have been already exported)
	if (is.null(mpi.cl) || !is.null(data)) {
		cat('+++ exporting data \n')
		Xdata.exp(cl, data, bdm$is.distance, bdm$is.sparse, normalize = bdm$normalize)
	}
	# +++ run ptsne
	if (!is.null(epochs)) bdm$epochs <- epochs
	if (!is.null(iters)) bdm$iters <- iters
	if (info == 2) progress <- bdm$progress
	cost <- bdm$ptsne$cost
	size <- bdm$ptsne$size
	bdm <- ptsne.restart(cl, bdm, info)
	if (!is.null(cost)) {
		if (bdm$ptsne$threads > 1) {
		 	if (nrow(cost) == nrow(bdm$ptsne$cost)) {
				bdm$ptsne$cost <- cbind(cost, bdm$ptsne$cost)
			}
		} else {
			bdm$ptsne$cost <- c(cost, bdm$ptsne$cost)
		}
	}
	bdm$ptsne$size <- c(size, bdm$ptsne$size)
	if (info == 2) bdm$progress <- c(progress, bdm$progress)
	# +++ stop cluster
	stopCluster(cl)
	return(bdm)
}

#' Perplexity-adaptive kernel density estimation
#'
#' Starts the paKDE algorithm (second step of the mapping protocol).
#'
#' @param bdm A \var{bdm} instance as generated by \code{bdm.init()}.
#'
#' @param layer The number of the t-SNE layer (1 by default).
#'
#' @param threads The number of parallel threads (in principle only limited by hardware resources, \code{i.e.} number of cores and available memory)
#'
#' @param type The type of cluster: 'SOCK' (default) for intra-node parallelization, 'MPI' (\code{message passing interface}) for inter-node parallelization.
#'
#' @param ppx The value of perplexity to compute similarities in the low-dimensional embedding (100 by default).
#'
#' @param g The resolution of the density space grid (\eqn{g*g} cells, 200 by default).
#'
#' @param g.exp A numeric factor to avoid border effects. The grid limits will be expanded so as to enclose the density of the kernel of the most extreme embedded datapoints up to \code{g.exp} times \eqn{\sigma}. By default, (\code{g.exp = 3}) the grid limits are expanded so as to enclose the 0.9986 of the probability mass of the most extreme kernels.
#'
#' @details When computing the \var{paKDE} the embedding area is discretized as a grid of size \code{g*g} cells. In order to avoid border effects, the limits of the grid are expanded by default so as to enclose at least the 0.9986 of the cumulative distribution function (\eqn{3 \sigma}) of the kernels of the most extreme mapped points in each direction.
#'
#' The presence of outliers in the embedding can lead to undesired expansion of the grid limits. We can overcome this using lower values of \var{g.exp}. By setting \code{g.exp = 0} the grid limits will be equal to the range of the embedding.
#'
#' The values \var{g.exp = c(1, 2, 3, 4, 5, 6)} enclose cdf values of \var{0.8413, 0.9772, 0.9986, 0.99996, 0.99999, 1.0} respectively.
#'
#' @return A copy of the input \var{bdm} instance with new element \var{bdm$pakde} (paKDE output). \code{bdm$pakde[[layer]]$layer = 'NC'} stands for not computed layers.
#'

#' @examples
#'
#' # --- load mapped dataset
#' bdm.example()
#' # --- run paKDE
#' \dontrun{
#' exMap <- bdm.pakde(exMap, threads = 4, ppx = 200, g = 200, g.exp = 3)
#' }
#' # --- plot paKDE output
#' bdm.pakde.plot(exMap)

bdm.pakde <- function(bdm, ppx = 100, g = 200, g.exp = 3, threads = 2, mpi.cl = NULL, layer = 1)
{
	# start cluster of workers
	cl <- cluster.start(threads, mpi.cl)
	if (is.null(cl)) return(bdm)
	# initialize bdm$pakde
	if (is.null(bdm$pakde)) bdm$pakde <- list()
	# compute kde
	l <- c(1, 2) + (layer- 1) *2
	if (!is.null(bdm$ptsne$Y[ , l])) {
		cat('+++ paKDE for layer ', layer, '/', bdm$ptsne$layers, ' +++ \n', sep='')
		bdm$pakde[[layer]] <- pakde.get(cl, bdm$ptsne$Y[ , l], ppx, g, g.exp)
	}
	else cat('+++ Error: up-stream step bdm.ptsne(layer = ', layer, ') not found ! \n', sep = '')
	# stop cluster
	stopCluster(cl)
	return(bdm)
}


#' Watertrack transform (WTT)
#'
#' Starts the WTT algorithm (third setp of the mapping protocol).
#'
#' @param bdm A \var{bdm} instance as generated by \code{bdm.init()}.
#'
#' @param layer The number of the t-SNE layer (1 by default).
#'
#' @return A copy of the input \var{bdm} instance with \var{bdm$wtt} (WTT output). \code{bdm$wtt[[layer]]$layer = 'NC'} stands for not computed layers.
#'
#' @details This function requires the up-stream step \code{bdm.pakde()}.
#'
#' @examples
#'
#' # --- load mapped dataset
#' bdm.example()
#' # --- perform WTT
#' exMap <- bdm.wtt(exMap)
#' # --- plot WTT output
#' bdm.wtt.plot(exMap)

bdm.wtt <- function(bdm, layer = 1)
{
	# initialize bdm$wtt
	if (is.null(bdm$wtt)) bdm$wtt <- list()
	# compute WTT
	if (!is.null(bdm$pakde[[layer]]$z))
	{
		cat('\n')
		cat('+++ WTT for layer ', layer, '/', bdm$ptsne$layers, ' +++ \n', sep='')
		bdm$wtt[[layer]] <- wtt.get(bdm$pakde[[layer]])
	}
	else cat('+++ Error: up-stream step bdm.pakde(layer = ', layer, ') not found ! \n', sep = '')
	return(bdm)
}


#' Get data-point clustering labels.
#'
#' Given that clusters are computed at grid-cell level, this function returns the clustering label for each data-point.
#'
#' @param bdm A \var{bdm} instance as generated by \code{bdm.init()}.
#'
#' @param layer The number of the t-SNE layer (1 by default).
#'
#' @param merged A logical value. If TRUE (default value) and the \var{bdm} has been merged, the data-point labelling indicate the number of the merged clusters. If \var{merged} is set to FALSE or the \var{bdm} has not been merged the data-point labels correspond to the top-level clustering.
#'
#' @return A vector of data-point clustering labels.
#'
#' @examples
#'
#' bdm.example()
#' exMap.labels <- bdm.labels(exMap)

bdm.labels <- function(bdm, merged = T, layer = 1){
	# At.!!! there is an internal version of this function (for simplicity)
	# check merge.labels() in bdm_merge.R if any change is to be made here !!
	if (!is.null(bdm$wtt[[layer]]))
	{
		C <- bdm$wtt[[layer]]$C
		if (merged && !is.null(bdm$merge)) {
			C <- bdm$merge$C
		}
		l <- c(1, 2) + (layer -1) *2
		D2c <- grid_D2cell(bdm$ptsne$Y[ , l], bdm$wtt[[layer]]$grid) +1
		x.size <- bdm$wtt[[layer]]$grid[1, 1]
		lbls <- C[(D2c[, 2] - 1) *x.size +D2c[, 1]]
	}
	else {
		lbls <- rep(1, nrow(bdm$ptsne$Y))
	}
	return(lbls)
}
