
# ------------------------------------------------------------------------------
# +++ bdm.list version (only for tech.report purposes)
# ------------------------------------------------------------------------------

bdm.list.qlty <- function(m.list, inp.data, threads = 4, type = 'SOCK', layers = 2, rounds = 5, qm = 'sp', verbose = TRUE)
{
	if  (is.null(inp.data)) {
		message('+++ Error: no data given !!')
		return(m.list)
	}
	# start cluster of workers
	cl <- cluster.start(threads, type, verbose = verbose)
	if (is.null(cl)) {
		message('+++ Error starting cluster !!')
		return(m.list)
	}
	# export input data
	Xdata.exp(cl, inp.data, m.list[[1]]$is.distance, m.list[[1]]$is.sparse)
	# chunk breaks
	breaks <- floor(seq(1, nrow(inp.data), length.out = threads +1))
	#
	for (i in seq_along(m.list)) {
		bdm <- m.list[[i]]
		# export Beta
		Xbeta.exp(cl, bdm$ppx$B)
		#. output data
		Ybm <- as.big.matrix(bdm$ptsne$Y[, 1:2], type='double')
		Ybm.dsc <- describe(Ybm)
		clusterExport(cl, c('Ybm.dsc'), envir=environment())
		clusterEvalQ(cl, Ybm <- attach.big.matrix(Ybm.dsc))
		#. dataset size
		nY <- nrow(Ybm)
		if (qm == 'sp') {
			Q <- qlty.get.sp(cl, nY, threads, layers, rounds, verbose)
			if (verbose) {
				message(paste('+++ ppx ', formatC(round(bdm$ppx$ppx /nY, 2), digits = 2, width = 4), sep = ''), ' ... ', qlty.format(Q))
			}
			m.list[[i]]$spQ <- Q
		}
		else if (qm == 'rb') {
			Q <- qlty.get.rb(cl, nY, threads, layers, rounds, verbose)
			if (verbose) {
				message(paste('+++ ppx ', formatC(round(bdm$ppx$ppx /nY, 2), digits = 2, width = 4), sep = ''), ' ... ', qlty.format(Q))
			}
			m.list[[i]]$rbQ <- Q
		}
		if (verbose) cat('\n')
	}
	#
	stopCluster(cl)
	return(m.list)
}


# -----------------------------------------------------------------------------
# bdm.list quality plotting utilities
# ------------------------------------------------------------------------------

bdm.list.qlty.plot <- function(m.list, qm = 'sp', y.lim = c(0.0, 1.0))
{
	parbdm.set(oma = c(3.0, 2.0, 3.0, 1.0), mar = c(3.0, 3.0, 1.5, 1.5))
	# blank plot
	plot(0, 1, type = 'n', xlab = 'model(m)', ylab = 'Qlty.', xlim = c(0, length(m.list)), ylim = y.lim)
	# models (perplexities)
	X <- seq(length(m.list))
	# methods
	if (qm == 'sp') {
		Q <- sapply(seq_along(m.list), function(i) apply(m.list[[i]]$spQ, 1, mean))
		F <- (Q[1, ] +Q[3, ]) /2
	} else if (qm == 'rb') {
		Q <- sapply(seq_along(m.list), function(i) apply(m.list[[i]]$rbQ, 1, mean))
		F <- Q[1, ] *Q[2, ] /(Q[1, ] +Q[2, ]) + Q[3, ] *Q[4, ] /(Q[3, ] +Q[4, ])
	}
	lines(X, F, col = 4, lw = 1.0)
	# legend
	if (qm == 'sp')
		legend('topright', legend = 'ptSNE', bty = 'n', lty = 1, cex = 1.0, col = 4)
	else if (qm == 'rb')
		legend('bottomright', legend = 'ptSNE', bty = 'n', lty = 1, cex = 1.0, col = 4)
	parbdm.def()
}

qlty.plot.sp.list <- function(m.list, par.set = T)
{
	if (par.set) {
		parbdm.set(oma = c(3.0, 2.0, 3.0, 1.0), mar = c(3.0, 3.0, 1.5, 1.5))
		layout(matrix(1:2, nrow = 1), widths = c(0.7, 0.3))
	}
	# color palette
	pltt <- c(rainbow(4), '#000000')
	# plot Q
	x <- seq(length(m.list))
	Q <- sapply(seq_along(m.list), function(i) apply(m.list[[i]]$spQ, 1, mean))
	plot(0, 1, type = 'n', xlab = 'model(m)', ylab = 'Qlty.', xlim = c(0, length(m.list)), ylim = c(0.0, 1.0))
	F <- (Q[1, ] +Q[3, ]) /2
	lines(x, Q[1, ], col = pltt[2], lty = 3, lw = .8)
	lines(x, Q[3, ], col = pltt[4], lty = 3, lw = .8)
	lines(x, F, col = pltt[5], lw = 1.0)
	# legend text
	legend.txt <- lapply(seq(0, length(m.list)), function(i) {
		if (i == 0) 'm  ppx   z   Q'
		else {
			bdm <- m.list[[i]]
			ppx <- formatC(round(bdm$ppx$ppx /nrow(bdm$ptsne$Y), 2), digits = 2)
			thread.size <- formatC(round(bdm$ptsne$layers /bdm$ptsne$threads, 2), digits = 2)
			paste(formatC(i, width = 2), ppx, thread.size, formatC(round(F[i], 4), digits = 4), sep = '  ')
		}
	})
	# plot legend
	par(mar = c(3.0, 0.1, 1.5, 0.5))
	plot(1, 1, xlab = '', ylab = '', xaxt = "n", yaxt = "n", bty = "n", type = "n")
	legend('left', legend = legend.txt, col = pltt[5], bty = 'n', lwd = 0, cex = 0.8)
	if (par.set) parbdm.def()
}

qlty.plot.rb.list <- function(m.list, y.min = 0.9, par.set = T)
{
	if (par.set) {
		parbdm.set(oma = c(3.0, 2.0, 3.0, 1.0), mar = c(3.0, 3.0, 1.5, 1.5))
		layout(matrix(1:2, nrow = 1), widths = c(0.7, 0.3))
	}
	# color palette
	pltt <- c(rainbow(4), '#000000')
	# plot Q
	x <- seq(length(m.list))
	Q <- sapply(seq_along(m.list), function(i) apply(m.list[[i]]$rbQ, 1, mean))
	plot(0, 1, type = 'n', xlab = 'model(m)', ylab = 'Qlty.', xlim = c(0, length(m.list)), ylim = c(y.min, 1.0))
	F <- Q[1, ] *Q[2, ] /(Q[1, ] +Q[2, ]) + Q[3, ] *Q[4, ] /(Q[3, ] +Q[4, ])
	lines(x, Q[1, ], col = pltt[1], lty = 3, lw = .8)
	lines(x, Q[2, ], col = pltt[2], lty = 3, lw = .8)
	lines(x, Q[3, ], col = pltt[3], lty = 3, lw = .8)
	lines(x, Q[4, ], col = pltt[4], lty = 3, lw = .8)
	lines(x, F, col = pltt[5], lw = 1.0)
	# legend text
	legend.txt <- lapply(seq(0, length(m.list)), function(i) {
		if (i == 0) 'm  ppx   z   Q'
		else {
			bdm <- m.list[[i]]
			ppx <- formatC(round(bdm$ppx$ppx /nrow(bdm$ptsne$Y), 2), digits = 2)
			thread.size <- formatC(round(bdm$ptsne$layers /bdm$ptsne$threads, 2), digits = 2)
			paste(formatC(i, digits = 2), ppx, thread.size, formatC(round(F[i], 4), digits = 4), sep = '  ')
		}
	})
	# plot legend
	par(mar = c(3.0, 0.1, 1.5, 0.5))
	plot(1, 1, xlab = '', ylab = '', xaxt = "n", yaxt = "n", bty = "n", type = "n")
	legend('left', legend = legend.txt, col = pltt[5], bty = 'n', lwd = 0, cex = 0.8)
	if (par.set) parbdm.def()
}

# ------------------------------------------------------------------------------
# +++ bdm.list comparative version (only for tech.report purposes)
# ------------------------------------------------------------------------------

bdm.xlist.qlty <- function(m.list, Xbm, threads = 10, type = 'SOCK', layers = 2, rounds = 5, qm = 'sp', verbose = TRUE)
{
	# start cluster of workers
	cl <- cluster.start(threads, type, verbose = verbose)
	if (is.null(cl)) return(NULL)
	# export input data
	Xdata.exp(cl, Xbm, m.list[[1]]$is.distance)
	# chunk breaks
	breaks <- floor(seq(1, nrow(X), length.out = threads +1))
	#
	for (i in seq_along(m.list)) {
		m <- m.list[[i]]
		# export Beta
		Xbeta.exp(cl, m$ppx$B)
		for (l in seq(length(m$xtsne))) {
			if (verbose)
				cat('+++', padleft(names(m$xtsne)[l], 6), '\n')
			#. output data
			Ybm <- as.big.matrix(m$xtsne[[l]]$Y, type='double')
			Ybm.dsc <- describe(Ybm)
			clusterExport(cl, c('Ybm.dsc'), envir=environment())
			clusterEvalQ(cl, Ybm <- attach.big.matrix(Ybm.dsc))
			#. dataset size
			n <- nrow(Ybm)
			if (qm == 'sp' && is.null(m$xtsne[[l]]$spQ)) {
				Q <- qlty.get.sp(cl, n, threads, layers, rounds, verbose)
				if (verbose) {
					message(paste('+++ ppx ', formatC(m$xtsne[[l]]$ppx, digits = 2, width = 4), sep = ''), ' ... ', qlty.format(Q))
				}
				m.list[[i]]$xtsne[[l]]$spQ <- Q
			}
			else if (qm == 'rb' && is.null(m$xtsne[[l]]$rbQ)) {
				Q <- qlty.get.rb(cl, n, threads, layers, rounds, verbose)
				if (verbose) {
					message(paste('+++ ppx ', formatC(m$xtsne[[l]]$ppx, digits = 2, width = 4), sep = ''), ' ... ', qlty.format(Q))
				}
				m.list[[i]]$xtsne[[l]]$rbQ <- Q
			}
			else if (qm == 'kn' && is.null(m$xtsne[[l]]$knQ)) {
				knQ <- qlty.get.kn(cl, n)
				m.list[[i]]$xtsne[[l]]$knQ <- knQ
				if (verbose) {
					message(paste('+++ ppx ', formatC(m$xtsne[[l]]$ppx, digits = 2, width = 4), sep = ''), ' ... ', formatC(round(knQ$AUC, 4), width = 7, digits = 4))
				}
			}
		}
		if (verbose) cat('\n')
	}
	#
	stopCluster(cl)
	return(m.list)
}

# ------------------------------------------------------------------------------
# +++ bdm.list qlty plot - comparative version (only for tech.report purposes)
# ------------------------------------------------------------------------------

bdm.xlist.qlty.plot <- function(m.list, qm = 'sp', y.lim = c(0.0, 1.0), m = 'ptsne')
{
	if (qm == 'kn')
	{
		m.list <- lapply(m.list, function(bdm) {
			if (!is.null(bdm$xtsne[[m]])) {
				bdm$knQ <- bdm$xtsne[[m]]$knQ
				bdm$xtsne <- NULL
				bdm
			}
		})
		m.list <- m.list[!sapply(m.list, is.null)]
		qlty.plot.kn.list(m.list)
	}
	else
	{
		parbdm.set(oma = c(3.0, 2.0, 3.0, 1.0), mar = c(3.0, 3.0, 1.5, 1.5))
		# blank plot
		plot(0, 1, type = 'n', xlab = 'model(m)', ylab = 'Qlty.', xlim = c(0, length(m.list)), ylim = y.lim)
		# color palette
		pltt <- c(4, 3, 2, 5)
		# models (perplexities)
		X <- seq(length(m.list))
		# methods
		mth.list <- names(m.list[[1]]$xtsne)
		nulL <- lapply(seq_along(mth.list), function(l) {
			name <- mth.list[l]
			if (qm == 'sp') {
				Q <- sapply(seq_along(m.list), function(i) {
					if (!is.null(m.list[[i]]$xtsne[[name]])) {
						apply(m.list[[i]]$xtsne[[name]]$spQ, 1, mean)
					} else numeric(4)
				})
				F <- (Q[1, ] +Q[3, ]) /2
				lines(X, F, col = pltt[l], lw = 1.0)
			} else if (qm == 'rb') {
				Q <- sapply(seq_along(m.list), function(i) {
					if (!is.null(m.list[[i]]$xtsne[[name]])) {
						apply(m.list[[i]]$xtsne[[name]]$rbQ, 1, mean)
					} else numeric(4)
				})
				F <- Q[1, ] *Q[2, ] /(Q[1, ] +Q[2, ]) + Q[3, ] *Q[4, ] /(Q[3, ] +Q[4, ])
				lines(X, F, col = pltt[l], lw = 1.0)
			}
		})
		# legend
		legend.txt <- names(m.list[[1]]$xtsne)
		if (qm == 'sp')
			legend('topright', legend = legend.txt, bty = 'n', lty = 1, cex = 1.0, col = pltt)
		else if (qm == 'rb')
			legend('bottomright', legend = legend.txt, bty = 'n', lty = 1, cex = 1.0, col = pltt)
		parbdm.def()
	}
}

bdm.xlist.qlty.plot.sp <- function(m.list, y.lim = c(0.0, 1.0), m = 'ptsne')
{
	parbdm.set(oma = c(3.0, 2.0, 3.0, 1.0), mar = c(3.0, 3.0, 1.5, 1.5))
	# blank plot
	plot(0, 1, type = 'n', xlab = 'model(m)', ylab = 'Qlty.', xlim = c(0, length(m.list)), ylim = y.lim)
	# color palette
	pltt <- c(4, 2, 3)
	# models (perplexities)
	X <- seq(length(m.list))
	Q <- sapply(seq_along(m.list), function(i) apply(m.list[[i]]$xtsne[[m]]$spQ, 1, mean))
	F <- (Q[1, ] +Q[3, ]) /2
	lines(X, Q[1, ], col = pltt[1], lty = 1, lw = 1.0)
	lines(X, Q[3, ], col = pltt[2], lty = 1, lw = 1.0)
	lines(X, F, col = 1, lty = 3, lw = 0.8)
	parbdm.def()
}
