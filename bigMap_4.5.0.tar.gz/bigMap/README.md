# bigMap
Big data mapping with paralellized t-SNE
