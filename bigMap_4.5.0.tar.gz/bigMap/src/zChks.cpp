/*
 The bigMap Package for R.

 Copyright (c) 2018, Joan Garriga <jgarriga@ceab.csic.es>, Frederic Bartumeus <fbartu@ceab.csic.es> (Blanes Centre for Advanced Studies, CEAB-CSIC).

 bigMap is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

 bigMap is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

 You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses.
*/

// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
// [[Rcpp::depends(BH, bigmemory)]]
#include <bigmemory/MatrixAccessor.hpp>

#include <numeric>      // std::iota
#include <algorithm>    // std::nth_element, std::sort, std::stable_sort

#include "mydist.h"
#include "affmtx.h"

// using namespace arma;
using namespace Rcpp;
using namespace std;

// Exact/Approx. MPI implementation of t-SNE
// [[Rcpp::export]]
void chk_zTSNE(arma::Mat<double> &Y, arma::Col<int> indexes)
{
	// size_t N = bmL->nrow();
	size_t thread_size = Y.n_rows;
	// int* zIdx = reinterpret_cast <int*> (I.begin());
	int* zIdx = indexes.begin();
	// . starting mapping positions
	double* thread_Y = (double*) malloc(thread_size *2 *sizeof(double));
	for (size_t i = 0; i < thread_size; i++) {
		for (size_t d = 0; d < 2; d++) {
			thread_Y[i *2 +d] = Y(i, d);
		}
	}
	// update mapping positions
	for (size_t i = 0; i < thread_size; i++) {
		for (size_t d = 0; d < 2; d++) {
			Y(i, d) = thread_Y[i *2 +d];
		}
	}
	// free memory
	free(thread_Y); thread_Y = NULL;
}

// check neighbors' set size
// [[Rcpp::export]]
Rcpp::NumericVector nnSS_chk(SEXP sexpX, SEXP sexpB, arma::Col<int> indexes, bool isDistance, bool isSparse, size_t nnSize)
{
	// indexes
	int* zIdx = indexes.begin();
	size_t thread_size = indexes.size();
	//. thread affinity matrix
	size_t aff_size = thread_size *(thread_size -1) /2;
	double* thread_P = (double*) calloc(aff_size, sizeof(double));
	// . indexes of data-point pairs with significant atractive forces
	int* thread_W = (int*) calloc(aff_size, sizeof(int));
	// . affinity matrix
	affMtx* affmtx = new affMtx(sexpX, sexpB, zIdx, thread_size, nnSize, 1.0);
	if (isDistance)
		affmtx ->D2P(thread_P, thread_W);
	else if (isSparse)
		affmtx ->S2P(thread_P, thread_W);
	else
		affmtx ->X2P(thread_P, thread_W);
	// . neighbors' set size
	Rcpp::NumericVector thread_nnSS(thread_size);
	thread_nnSS.fill(0);
	for (size_t i = 0; i < thread_size; i++) {
		for (size_t j = i +1; j < thread_size; j++) {
			size_t ij = ijIdx(thread_size, i, j);
			if (thread_P[ijIdx(thread_size, i, j)] > 0) {
				thread_nnSS[i] ++;
				thread_nnSS[j] ++;
			}
		}
	}
	// free memory
	// delete affmtx;
	free(thread_W); thread_W = NULL;
	free(thread_P); thread_P = NULL;
	return thread_nnSS;
}

// check thread affinity matrix
// [[Rcpp::export]]
Rcpp::NumericMatrix aff_chk(SEXP sexpX, SEXP sexpB, arma::Col<int> indexes, bool isDistance, bool isSparse, size_t nnSize)
{
	// indexes
	int* zIdx = indexes.begin();
	size_t thread_size = indexes.size();
	//. thread affinity matrix
	size_t aff_size = thread_size *(thread_size -1) /2;
	double* thread_P = (double*) calloc(aff_size, sizeof(double));
	// . indexes of data-point pairs with significant atractive forces
	int* thread_W = (int*) calloc(aff_size, sizeof(int));
	// . affinity matrix
	affMtx* affmtx = new affMtx(sexpX, sexpB, zIdx, thread_size, nnSize, 1.0);
	if (isDistance)
		affmtx ->D2P(thread_P, thread_W);
	else if (isSparse)
		affmtx ->S2P(thread_P, thread_W);
	else
		affmtx ->X2P(thread_P, thread_W);
	//. thread affinity matrix
	Rcpp::NumericMatrix zAffMtx(thread_size, thread_size);
	// . neighbors' set size
	for (size_t i = 0; i < thread_size; i++) {
		for (size_t j = i +1; j < thread_size; j++) {
			size_t ij = ijIdx(thread_size, i, j);
			zAffMtx(i, j) = thread_P[ij];
			zAffMtx(j, i) = thread_P[ij];
		}
	}
	// free memory
	delete affmtx;
	free(thread_W); thread_W = NULL;
	free(thread_P); thread_P = NULL;
	// return affinity matrix
	return zAffMtx;
}

// row distances
// [[Rcpp::export]]
std::vector<double> rowDist(SEXP sexpX, bool is_distance, bool is_sparse, size_t row, size_t ppx)
{
	// input data
	sqDist* sqDistX = new sqDist(sexpX);
	// squared distances
	std::vector<double> Li(sqDistX ->nX);
	if (is_sparse) {
		sqDistX ->row_spDist(row, Li.data());
	}
	else if (is_distance) {
		sqDistX ->row_d2Dist(row, Li.data());
	}
	else {
		sqDistX ->row_d1Dist(row, Li.data());
	}
	// nearest-neighbor quantile
	int nnQ = std::min((int) 3 *ppx, sqDistX ->nX -1);
	std::nth_element(Li.begin(), Li.begin() +nnQ, Li.end());
	return Li;
}


// entropy
double rowEntropy(std::vector<double> Li, double Bi, double &Zi, int nnQ)
{
	// Att!! Hi = \sum_j Pij/Pi log(Pij/Pi);
	// where:
	// Pij = exp(-Bi *Lij)
	// log(Pij) = -Bi *Lij (note the sign !!!)
	Zi = -1.0;
	double Hi = .0;
	// // entropy (up to 32.0/Bi)
	// double maxL = 32.0 /Bi;
	// for (size_t j = 0; j < Li.size(); j++) {
	// 	if (Li[j] <= maxL) {
	// 		double Kij = std::exp(-Bi *Li[j]);
	// 		Zi += Kij;
	// 		Hi += Li[j] *Kij;
	// 	}
	// }
	// entropy (up to nnQ)
	for (size_t j = 0; j < nnQ; j++) {
		double Kij = std::exp(-Bi *Li[j]);
		Zi += Kij;
		Hi += Li[j] *Kij;
	}
	// Att!! Two problems may arise that cause Zi = 0:
	// 1. datapoints for which the starting value Bi = 1 is too large
	// (i.e, distances to all neighbors are greater than 32.0/Bi)
	// 2. datapoints with many nearest neighbours at the same distance for which,
	// increasing Bi suddenly places them all out of the neighborhood
	// In any case, Hi = 0 and Bi is decreased in the next step.
	if (Zi > 0) {
		Hi *= Bi /Zi;
		Hi += std::log(Zi);
	}
	return Hi;
}

// row beta (Att!!!! expects X transposed +++++++++++++++++++++++++++++++++++)
// [[Rcpp::export]]
std::vector<double> rowBeta(SEXP sexpX, bool is_distance, bool is_sparse, size_t row, size_t ppx, double xppx, double iniB)
{
	// input data
	sqDist* sqDistX = new sqDist(sexpX);

	// parameters
	double logppx = std::log(ppx);
	double ppxtol = std::log(1 /.99999);
	int nnQ = std::min((int) (xppx *ppx +1), (int) (sqDistX ->nX -1));
	double stdppx = std::pow((std::log(std::sqrt(2 *3.14159265359)) -logppx), 2.0);

	// squared distances
	std::vector<double> Li(sqDistX ->nX);
	if (is_sparse) {
		sqDistX ->row_spDist(row, Li.data());
	}
	else if (is_distance) {
		sqDistX ->row_d2Dist(row, Li.data());
	}
	else {
		sqDistX ->row_d1Dist(row, Li.data());
	}

	// make a (deep) copy for complet sorting
	// std::vector<double> Di = Li;

	// get indexes
	// std::vector<int> I(sqDistX ->nX);
	// std::iota(I.begin(), I.end(), 0);
	// std::sort(I.begin(), I.end(), [&](int a, int b) {return Di[a] < Di[b];} );

	// nearest-neighbor quantile
	std::nth_element(Li.begin(), Li.begin() +nnQ, Li.end());
	double nnQBeta = stdppx /Li[nnQ];

	// printf("+++ %5zu:\n", row);
	// for (int j = 0; j < nnQ; j++) printf(" %5d, %9.6f --", I[j], Di[I[j]]);
	// printf("\n");
	// // sort selected neighborhood
	// std::vector<double> Si(nnQ);
	// for (int j = 0; j < nnQ; j++) Si[j] = Li[j];
	// std::sort(Si.begin(), Si.end());
	// printf("+++ selected neighborhood:\n");
	// for (int j = 0; j < nnQ; j++) printf(" %9.6f --", Si[j]);
	// printf("\n");

	std::vector<double> Beta(3);
	double Bi = iniB, minBeta = 0, maxBeta = DBL_MAX;
	double Zi;
	for (size_t iter = 0; iter < 100; iter++) {
		if (Bi > nnQBeta) {
			Bi = nnQBeta;
			double Hi = rowEntropy(Li, Bi, Zi, nnQ);
			printf("%3zu, %9.6f, %9.6f, %9.6f \n", iter, Bi, Zi, Hi);
			break;
		}
		// compute log-perplexity for current Beta
		double Hi = rowEntropy(Li, Bi, Zi, nnQ);
		double diff = logppx -Hi;
		printf("%3zu, %9.6f, %9.6f, %9.6f \n", iter, Bi, Zi, Hi);
		// check tolerance
		if (std::abs(diff) < ppxtol) break;
		// adjust Beta
		if (diff < 0) {
			minBeta = Bi;
			if (maxBeta == DBL_MAX) Bi *= 2.0;
			else Bi = (Bi +maxBeta) /2.0;
		}
		else {
			maxBeta = Bi;
			Bi = (Bi +minBeta) /2.0;
		}
	}

	// precision
	Beta[0] = Bi;
	// conditional affinity normalization factor
	// I can drop the 1/n factor because affinities are renormalized
	// by thread (by factor zP) when attractive forces are computed
	// Beta(1, l) = Zi *2.0 *sqDistX ->nX;
	Beta[1] = Zi *2.0;
	// nearest-neighbor quantile
	Beta[2] = Li[nnQ];
	// free memory
	delete sqDistX;
	//
	return Li;
}
