/*
 The bigMap Package for R.

 Copyright (c) 2018, Joan Garriga <jgarriga@ceab.csic.es>, Frederic Bartumeus <fbartu@ceab.csic.es> (Blanes Centre for Advanced Studies, CEAB-CSIC).

 bigMap is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

 bigMap is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

 You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses.
*/

//[[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
// [[Rcpp::depends(BH, bigmemory)]]
#include <bigmemory/MatrixAccessor.hpp>

#include <math.h>
#include <float.h>

using namespace Rcpp;

static inline int tIdx(int n, int i, int j) {
	return ( (n*i) - (i+1)*(i+2)/2 + j );
}

// get chunks by thread: indexes and mapping-positions
// [[Rcpp::export]]
void iChnks_get(Rcpp::List& iChnks_list, const arma::Col<int>& I, const Rcpp::List& brks_list)
{
	for (int z = 0; z < brks_list.length(); z++)
	{
		arma::Mat<int> brks = brks_list[z];
		arma::Col<double> iChnk = iChnks_list[z];
		size_t j = 0;
		for (size_t l = 0; l < brks.n_rows; l++) {
			for (size_t i = brks(l, 0); i < brks(l, 1); i++) {
				iChnk[j] = I[i];
				j++;
			}
		}
		iChnks_list[z] = iChnk;
	}
}

// Similarity distribution entropy
// [[Rcpp::export]]
double zSK_get(int thread_rank, int threads, size_t layers, SEXP sexpX, int m, SEXP sexpB, const arma::Col<int>& I)
{
	// input data
	Rcpp::XPtr<BigMatrix> bmX(sexpX);
	MatrixAccessor<double> X(*bmX);
	// input Betas
	Rcpp::XPtr<BigMatrix> bmB(sexpB);
	MatrixAccessor<double> B(*bmB);
	//
	size_t n = I.size();
	size_t p = n * (n-1) / 2;

	// // thread input data
	// double* zX = (double*) malloc(n *m * sizeof(double));
	// double* zB = (double*) malloc(n * sizeof(double));
	// if (zX == NULL || zB == NULL) Rcpp::stop("Memory allocation failed! \n");

	// .similarity conditional distribution
	double* Ki = (double*) malloc(n * sizeof(double));
	double* P  = (double*) calloc(p, sizeof(double));
	if (Ki == NULL || P == NULL) Rcpp::stop("Memory allocation failed! \n");

	// // local copy of input-data and betas
	// // this is MUCH FASTER than directly accesing X and B in the loop below
	// // (because of multi-threading locks)
	// for (size_t i = 0; i < n; i++) {
	// 	for (size_t v = 0; v < m; v++) zX[i *m + v] = X[v][I[i]];
	// 	zB[i] = B[0][I[i]];
	// }
	// The above is NOT true, or NOT significant

	// compute similarities join distribution
	for (size_t i = 0; i < n; i++) {
		double Zi = .0;
		for (size_t j = 0; j < n; j++) {
			Ki[j] = .0;
			if (j != i) {
				double Lij = .0;
				// for(size_t v = 0; v < m; v++) Lij += std::pow(zX[i *m +v] -zX[j *m +v], 2);
				// Ki[j] = std::exp(- zB[i] *Lij) + FLT_MIN;	// do NOT remove FLT_MIN !!
				for(size_t v = 0; v < m; v++) Lij += std::pow(X[v][I[i]] -X[v][I[j]], 2);
				Ki[j] = std::exp(- B[0][i] *Lij) + FLT_MIN;	// do NOT remove FLT_MIN !!
				Zi += Ki[j];
			}
		}
		Zi *= (2.0 *n);
		for (size_t j = 0; j < i; j++) {
			size_t ji = tIdx(n, j, i);
			P[ji] += Ki[j] /Zi;
		}
		for (size_t j = i+1; j < n; j++) {
			size_t ij = tIdx(n, i, j);
			P[ij] += Ki[j] /Zi;
		}
	}
	// compute K(P)
	double K = .0;
	// double sumP = .0;
	for (size_t ij = 0; ij < p; ij++) {
		K += P[ij] * std::log(P[ij]);
		// K += 2 * P[ij] * P[ij];
		// sumP += 2 *P[ij];
	}
	K /= std::log(p);
	K += 1.0;
	// printf("+++ sumP. %6.4f \n", sumP);

	// deallocate memory
	// free(zX); zX = NULL;
	// free(zB); zB = NULL;
	free(Ki); Ki = NULL;
	free(P); P = NULL;
	return K;
}
